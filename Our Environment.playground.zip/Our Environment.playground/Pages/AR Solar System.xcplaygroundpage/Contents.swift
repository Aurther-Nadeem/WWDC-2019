//: # WWDC 2019 Scholarship Submission by Aurther Nadeem
// Images used from https://www.solarsystemscope.com/textures
// Royalty Free Music from https://youtu.be/1CMC3dM8m18

import UIKit 
import ARKit
import SceneKit
import PlaygroundSupport
import AVFoundation

//: Welcome to my Playground! This is my third year applying if I get a Scholarship this will be my first WWDC. Anyway more about that later...
//: Let's Get Started!
//: >I recommend you turn off silent and turn up your volume 👌🏽. Also, hold your iPad Pro, horizontally with volume buttons facing up for the best User Experiance.
//: >Run the code, and if you want more planets 🌍 you can go down to the big flashy row of emojis and read the note before changing a tiny bit of code 👍🏽.
//: >1️⃣ Point your iPad Pro and see the planets and how they spin. By the way they are spinning at different speeds, just like in real life 🤯.
//: >2️⃣ Once you've seen the solAR system (I love that pun 😂) you can move on to what we are doing to our Planet and Atmosphere.
//: >3️⃣ To move on just click the little red '>' arrow at the top.


var player = AVAudioPlayer()

class ViewController: NSObject, ARSCNViewDelegate{
    var sceneView: ARSCNView
    init(ARsceneView: ARSCNView) {
        self.sceneView = ARsceneView
        
        super.init()
        
        self.sceneView.debugOptions = []
        self.setupWorldTracking()
        
    }
    
    private func setupWorldTracking() {
        if ARWorldTrackingConfiguration.isSupported{
            let config = ARWorldTrackingConfiguration()
            config.planeDetection = .horizontal
            config.isLightEstimationEnabled = true
            self.sceneView.session.run(config, options: [])
            music()
            createSun()
            createMer()
            createVen()
            createEar()
            createMoo()
            //⭐️⭐️⭐️⭐️⭐️⭐️⭐️⭐️⭐️⭐️⭐️⭐️⭐️⭐️⭐️⭐️⭐️⭐️⭐️⭐️⭐️⭐️⭐️⭐️⭐️⭐️⭐️⭐️⭐️⭐️⭐️⭐️⭐️⭐️⭐️⭐️⭐️⭐️⭐️
            // Was that flashy or not? 😂
            // Some of the Planets are Turned off because my iPad can't handle all of the planets at once. If you want, you can remove them from the Comments. However, the Playground may not be able to run the code and will say "Problems running Playground". To fix just re-comment the uncommented planet. 
            //createMars()
            //createJup()
            //createSat()
            //createUra()
            //createNep()
        }
    }
    
    func music(){
        let ARMusic = Bundle.main.url(forResource: "ARSong", withExtension: "mp3")
        
        player = try! AVAudioPlayer(contentsOf: ARMusic!)
        player.play()
    }
    
    func createSun() {
        
        let sunSphere = SCNSphere(radius: 0.3)
        let sunNode = SCNNode(geometry: sunSphere)
        
        sunSphere.firstMaterial?.diffuse.contents = UIImage(named: "Sun.JPG")
        
        sunNode.position = SCNVector3(-0.5, 0, -1.5)
        
        sceneView.scene.rootNode.addChildNode(sunNode)
        
        
    }
    
    func createMer()
    {
        let merSphere = SCNSphere(radius: 0.1)
        let merNode = SCNNode(geometry: merSphere)
        
        merSphere.firstMaterial?.diffuse.contents = UIImage(named: "Mercury.JPG")
        
        merNode.position = SCNVector3(0, 0, -1.5)
        
        sceneView.scene.rootNode.addChildNode(merNode)
        
        let action = SCNAction.rotate(by: 360 * CGFloat((M_PI) / 180.0), around: SCNVector3(0, 1, 0), duration: 8)
        let repeatAction = SCNAction.repeatForever(action)
        merNode.runAction(repeatAction)
        
    }
    
    func createVen() {
        
        let venSphere = SCNSphere(radius: 0.15)
        let venNode = SCNNode(geometry: venSphere)
        
        venSphere.firstMaterial?.diffuse.contents = UIImage(named: "Venus.JPG")
        venSphere.firstMaterial?.emission.contents = UIImage(named: "VenusAtmosphere.JPG")
        
        venNode.position = SCNVector3(0.4, 0, -1.5)
        
        sceneView.scene.rootNode.addChildNode(venNode)
        
        let action = SCNAction.rotate(by: 360 * CGFloat((M_PI) / 180.0), around: SCNVector3(0, 1, 0), duration: 7)
        let repeatAction = SCNAction.repeatForever(action)
        venNode.runAction(repeatAction)
        
    }
    
    func createEar() {
        
        let earSphere = SCNSphere(radius: 0.17)
        let earNode = SCNNode(geometry: earSphere)
        
        earSphere.firstMaterial?.diffuse.contents = UIImage(named: "Earth.JPG")
        earSphere.firstMaterial?.specular.contents = UIImage(named: "EarthNight.JPG")
        earSphere.firstMaterial?.emission.contents = UIImage(named: "EarthClouds.JPG")
        
        earNode.position = SCNVector3(0.9, 0, -1.5)
        
        sceneView.scene.rootNode.addChildNode(earNode)
        
        let action = SCNAction.rotate(by: 360 * CGFloat((M_PI) / 180.0), around: SCNVector3(0, 1, 0), duration: 6)
        let repeatAction = SCNAction.repeatForever(action)
        earNode.runAction(repeatAction)
        
    }
    
    func createMoo() {
        
        let mooSphere = SCNSphere(radius: 0.05)
        let mooNode = SCNNode(geometry: mooSphere)
        
        mooSphere.firstMaterial?.diffuse.contents = UIImage(named: "Moon.JPG")
        
        mooNode.position = SCNVector3(1.2, 0.15, -1.5)
        
        sceneView.scene.rootNode.addChildNode(mooNode)
        
        let action = SCNAction.rotate(by: 360 * CGFloat((M_PI) / 180.0), around: SCNVector3(0, 1, 0), duration: 5.5)
        let repeatAction = SCNAction.repeatForever(action)
        mooNode.runAction(repeatAction)
        
    }
    
    func createMars() {
        
        let marSphere = SCNSphere(radius: 0.15)
        let marNode = SCNNode(geometry: marSphere)
        
        marSphere.firstMaterial?.diffuse.contents = UIImage(named: "Mars.JPG")
        
        marNode.position = SCNVector3(1.5, 0, -1.5)
        
        sceneView.scene.rootNode.addChildNode(marNode)
        
        let action = SCNAction.rotate(by: 360 * CGFloat((M_PI) / 180.0), around: SCNVector3(0, 1, 0), duration: 5)
        let repeatAction = SCNAction.repeatForever(action)
        marNode.runAction(repeatAction)
        
    }
    
    func createJup() {
        
        let jupSphere = SCNSphere(radius: 0.2)
        let jupNode = SCNNode(geometry: jupSphere)
        
        jupSphere.firstMaterial?.diffuse.contents = UIImage(named: "Jupiter.JPG")
        
        jupNode.position = SCNVector3(2.1, 0, -1.5)
        
        sceneView.scene.rootNode.addChildNode(jupNode)
        
        let action = SCNAction.rotate(by: 360 * CGFloat((M_PI) / 180.0), around: SCNVector3(0, 1, 0), duration: 4)
        let repeatAction = SCNAction.repeatForever(action)
        jupNode.runAction(repeatAction)
        
    }
    
    func createSat() {
        
        let satSphere = SCNSphere(radius: 0.2)
        let satNode = SCNNode(geometry: satSphere)
        
        satSphere.firstMaterial?.diffuse.contents = UIImage(named: "Saturn.JPG")
        
        satNode.position = SCNVector3(2.5, 0, -1.5)
        
        sceneView.scene.rootNode.addChildNode(satNode)
        
        let action = SCNAction.rotate(by: 360 * CGFloat((M_PI) / 180.0), around: SCNVector3(0, 1, 0), duration: 4.5)
        let repeatAction = SCNAction.repeatForever(action)
        satNode.runAction(repeatAction)
        
    }
    
    func createUra() {
        
        let uraSphere = SCNSphere(radius: 0.17)
        let uraNode = SCNNode(geometry: uraSphere)
        
        uraSphere.firstMaterial?.diffuse.contents = UIImage(named: "IMG_0462.JPG")
        
        uraNode.position = SCNVector3(3, 0, -1.5)
        
        sceneView.scene.rootNode.addChildNode(uraNode)
        
        let action = SCNAction.rotate(by: 360 * CGFloat((M_PI) / 180.0), around: SCNVector3(0, 1, 0), duration: 2)
        let repeatAction = SCNAction.repeatForever(action)
        uraNode.runAction(repeatAction)
        
    }
    
    func createNep() {
        
        let nepSphere = SCNSphere(radius: 0.19)
        let nepNode = SCNNode(geometry: nepSphere)
        
        nepSphere.firstMaterial?.diffuse.contents = UIImage(named: "IMG_0461.JPG")
        
        nepNode.position = SCNVector3(3.4, 0, -1.5)
        
        
        sceneView.scene.rootNode.addChildNode(nepNode)
        
        let action = SCNAction.rotate(by: 360 * CGFloat((M_PI) / 180.0), around: SCNVector3(0, 1, 0), duration: 1)
        let repeatAction = SCNAction.repeatForever(action)
        nepNode.runAction(repeatAction)
        
    }
    
}


let sceneView = ARSCNView()
let viewController = ViewController(ARsceneView: sceneView)
PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.liveView = viewController.sceneView
PlaygroundPage.current.wantsFullScreenLiveView = true








