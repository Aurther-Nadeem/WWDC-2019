//: # Learn About Our Finite Resources
import UIKit
import PlaygroundSupport
import AVFoundation

//: You can use an Apple Pencil to Swipe Left or Right.
//: > The Animations on this page may be a bit laggy because of Swift Playground not giving hardware acceleration like an iOS App built on Xcode would. For best results please swipe left and right very slowly. 🙃

func degreeToRadians (deg:CGFloat) -> CGFloat {
    return (deg * CGFloat.pi)/180
}
var player = AVAudioPlayer()

class View: UIView {
    
    let transformLayer = CATransformLayer()
    var currentAngle:CGFloat = 0
    var currentOffset:CGFloat = 0
    
    let imageOne = CALayer()
    
    override init(frame: CGRect) {
        
        
        
        func addImageCard(name: String){
            
            let imageCardSize = CGSize(width: 200, height: 300)
            
            let imageLayer = CALayer()
            imageLayer.frame = CGRect(x: self.bounds.midX , y: self.bounds.midY *   1.15, width: imageCardSize.width, height: imageCardSize.height)
            imageLayer.anchorPoint = CGPoint(x: 0.5, y: 0.5)
            
            guard let imageCardImage = UIImage(named: name)?.cgImage else {return}
            
            imageLayer.contents = imageCardImage
            imageLayer.contentsGravity = .resizeAspectFill
            imageLayer.masksToBounds = true
            imageLayer.isDoubleSided = true
            imageLayer.borderColor = UIColor(white: 1, alpha: 0.5).cgColor
            imageLayer.borderWidth = 5
            imageLayer.cornerRadius = 10
            transformLayer.addSublayer(imageLayer)
            
        }
        
        
        super.init(frame: frame)
        
        let ourEnvironment = UILabel(frame: CGRect(x: 16, y: 10, width: 200, height: 50))
        ourEnvironment.backgroundColor = .clear
        ourEnvironment.textColor = .yellow
        ourEnvironment.textAlignment = .center
        ourEnvironment.text = "Our Environment: "
        ourEnvironment.font = UIFont.boldSystemFont(ofSize: 22)
        ourEnvironment.layer.cornerRadius = 10
        ourEnvironment.layer.borderColor = UIColor.yellow.cgColor
        ourEnvironment.layer.borderWidth = 3
        ourEnvironment.layer.shadowColor = ourEnvironment.layer.borderColor
        ourEnvironment.layer.shadowRadius = 5
        ourEnvironment.layer.shadowOpacity = 0.9
        ourEnvironment.layer.shadowOffset = CGSize(width: 0, height: 5)
        addSubview(ourEnvironment)
        
        let theAtmosphere = UILabel(frame: CGRect(x: 230, y: 10, width: 180, height: 50))
        theAtmosphere.backgroundColor = .clear
        theAtmosphere.textColor = .cyan
        theAtmosphere.textAlignment = .center
        theAtmosphere.text = "Finite Resources"
        theAtmosphere.font = UIFont.boldSystemFont(ofSize: 20)
        theAtmosphere.layer.cornerRadius = 10
        theAtmosphere.layer.borderColor = UIColor.cyan.cgColor
        theAtmosphere.layer.borderWidth = 3
        theAtmosphere.layer.shadowColor = theAtmosphere.layer.borderColor
        theAtmosphere.layer.shadowRadius = 5
        theAtmosphere.layer.shadowOpacity = 0.9
        theAtmosphere.layer.shadowOffset = CGSize(width: 0, height: 5)
        addSubview(theAtmosphere)
        
        transformLayer.frame = self.bounds
        self.layer.addSublayer(transformLayer)
        
        for i in 1 ... 6 {
            addImageCard(name: "\(i).JPG")
            
        }
        
        turnCarousel()
        
        
        
        let panRecognizer = UIPanGestureRecognizer(target: self, action: #selector(performPanAction(recognizer:)))
        addGestureRecognizer(panRecognizer)
        
        backgroundColor = UIColor(red: 0.088, green: 0.086, blue: 0.214, alpha: 1)
        
        music()
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func turnCarousel(){
        guard let transformSubLayers = transformLayer.sublayers else {return}
        
        let segmentForImageCard = CGFloat(360 / transformSubLayers.count)
        
        var angleOffset = currentAngle
        
        for layer in transformSubLayers {
            var transform = CATransform3DIdentity
            transform.m34 = -1 / 500
            transform = CATransform3DRotate(transform, degreeToRadians(deg: angleOffset), 0, 1, 0)
            transform = CATransform3DTranslate(transform, 0, 0, 200)
            
            CATransaction.setAnimationDuration(0)
            
            layer.transform = transform
            
            angleOffset += segmentForImageCard
        }
    }
    
    @objc func performPanAction(recognizer: UIPanGestureRecognizer) {
        let xOffset = recognizer.translation(in: self).x
        
        if recognizer.state == .began {
            currentOffset = 0
        }
        
        let xDiff = xOffset * 0.5 - currentOffset
        
        currentOffset += xDiff
        currentAngle += xDiff
        
        turnCarousel()
        
        
        
    }
    
    func music(){
        let ARMusic = Bundle.main.url(forResource: "TerraformOne", withExtension: "m4a")
        
        player = try! AVAudioPlayer(contentsOf: ARMusic!)
        player.play()
    }
    
}

let view = View(frame: CGRect(x: 0, y: 0, width: 950, height: 300))

PlaygroundPage.current.liveView = view
PlaygroundPage.current.wantsFullScreenLiveView = true
