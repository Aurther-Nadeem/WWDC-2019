//: # Let's Check Out Our Atmosphere!
// Images used from https://www.solarsystemscope.com/textures

import UIKit 
import ARKit
import SceneKit
import PlaygroundSupport
import AVFoundation

//: > With my testing, please hold your iPad Pro Volume buttons up and horizontal for the best results. 👌🏽 Also turn up the volume 🔊 .


var player = AVAudioPlayer()
var secondPlayer = AVAudioPlayer()

class ViewController: NSObject, ARSCNViewDelegate{
    var sceneView: ARSCNView
    init(ARsceneView: ARSCNView) {
        self.sceneView = ARsceneView
        
        super.init()
        
        self.sceneView.debugOptions = []
        self.setupWorldTracking()
        
    }
    
    private func setupWorldTracking() {
        if ARWorldTrackingConfiguration.isSupported{
            let config = ARWorldTrackingConfiguration()
            config.planeDetection = .horizontal
            config.isLightEstimationEnabled = true
            self.sceneView.session.run(config, options: [])
            music()
            createEar()
            Timer.scheduledTimer(timeInterval: 5, target: self, selector: #selector(changeToJustSky), userInfo: nil, repeats: false)
            
        }
    }
    
    func music(){
        let ARMusic = Bundle.main.url(forResource: "Isolate", withExtension: "m4a")
        let Explaination = Bundle.main.url(forResource: "TropTrop", withExtension: "m4a")
        player = try! AVAudioPlayer(contentsOf: ARMusic!)
        secondPlayer = try! AVAudioPlayer(contentsOf: Explaination!)
        player.prepareToPlay()
        secondPlayer.prepareToPlay()
    }
    let earSphere = SCNSphere(radius: 0.17)
    func createEar() {
        
        
        let earNode = SCNNode(geometry: earSphere)
        
        earSphere.firstMaterial?.diffuse.contents = UIImage(named: "Earth.JPG")
        earSphere.firstMaterial?.specular.contents = UIImage(named: "EarthNight.JPG")
        earSphere.firstMaterial?.emission.contents = UIImage(named: "EarthClouds.JPG")
        
        earNode.position = SCNVector3(0, 0, -1.5)
        
        sceneView.scene.rootNode.addChildNode(earNode)
        
        let action = SCNAction.rotate(by: 360 * CGFloat((M_PI) / 180.0), around: SCNVector3(0, 1, 0), duration: 6)
        let moveEarth = SCNAction.move(to: SCNVector3(0, -0.05, -0.5), duration: 5)
        player.play()
        let repeatAction = SCNAction.repeatForever(action)
        earNode.runAction(repeatAction)
        earNode.runAction(moveEarth)
    }
    @objc func changeToJustSky() {
        earSphere.firstMaterial?.diffuse.contents = UIImage(named: "EarthClouds.JPG")
        earSphere.firstMaterial?.specular.contents = UIImage(named: "EarthClouds.JPG")
        earSphere.firstMaterial?.emission.contents = UIImage(named: "EarthClouds.JPG")
        secondPlayer.play()
    }
    
}


let sceneView = ARSCNView()
let viewController = ViewController(ARsceneView: sceneView)
PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.liveView = viewController.sceneView
PlaygroundPage.current.wantsFullScreenLiveView = true










