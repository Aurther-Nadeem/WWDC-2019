//: # Learn about Terraforming!
// Images used from https://www.solarsystemscope.com/textures
// Royalty Free Sound Effect from https://youtu.be/OqLuN-BIs9I
import UIKit 
import ARKit
import SceneKit
import PlaygroundSupport
import AVFoundation

//: > Be sure to point at Mars to see the terraforming take place. I know this is getting repetitive 😂 but... With my testing, please hold your iPad Pro Volume buttons up and horizontal for the best results. 👌🏽 Also turn up the volume 🔊 .

var player = AVAudioPlayer()

class ViewController: NSObject, ARSCNViewDelegate{
    var sceneView: ARSCNView
    init(ARsceneView: ARSCNView) {
        self.sceneView = ARsceneView
        
        super.init()
        
        self.sceneView.debugOptions = []
        self.setupWorldTracking()
        
    }
    
    private func setupWorldTracking() {
        if ARWorldTrackingConfiguration.isSupported{
            let config = ARWorldTrackingConfiguration()
            config.planeDetection = .horizontal
            config.isLightEstimationEnabled = true
            self.sceneView.session.run(config, options: [])
            music()
            createEar()
            createMoo()
            createMars()
            createRing()
            
            Timer.scheduledTimer(timeInterval: 5, target: self, selector: #selector(changeMarsToEarth), userInfo: nil, repeats: false)
            
        }
    }
    
    func music(){
        let ARMusic = Bundle.main.url(forResource: "Teraform", withExtension: "mp3")
        
        player = try! AVAudioPlayer(contentsOf: ARMusic!)
        player.prepareToPlay()
    }
    
    
    func createEar() {
        
        let earSphere = SCNSphere(radius: 0.17)
        let earNode = SCNNode(geometry: earSphere)
        
        earSphere.firstMaterial?.diffuse.contents = UIImage(named: "Earth.JPG")
        earSphere.firstMaterial?.specular.contents = UIImage(named: "EarthNight.JPG")
        earSphere.firstMaterial?.emission.contents = UIImage(named: "EarthClouds.JPG")
        
        earNode.position = SCNVector3(-0.8, 0, -1.5)
        
        sceneView.scene.rootNode.addChildNode(earNode)
        
        let action = SCNAction.rotate(by: 360 * CGFloat((M_PI) / 180.0), around: SCNVector3(0, 1, 0), duration: 6)
        let repeatAction = SCNAction.repeatForever(action)
        earNode.runAction(repeatAction)
        
    }
    
    func createMoo() {
        
        let mooSphere = SCNSphere(radius: 0.05)
        let mooNode = SCNNode(geometry: mooSphere)
        
        mooSphere.firstMaterial?.diffuse.contents = UIImage(named: "Moon.JPG")
        
        mooNode.position = SCNVector3(-0.5, 0.15, -1.5)
        
        sceneView.scene.rootNode.addChildNode(mooNode)
        
        let action = SCNAction.rotate(by: 360 * CGFloat((M_PI) / 180.0), around: SCNVector3(0, 1, 0), duration: 5.5)
        let repeatAction = SCNAction.repeatForever(action)
        mooNode.runAction(repeatAction)
        
    }
    
    let marSphere = SCNSphere(radius: 0.15)
    
    
    func createMars() {
        
        let marNode = SCNNode(geometry: marSphere)
        
        marSphere.firstMaterial?.diffuse.contents = UIImage(named: "Mars.JPG")
        marSphere.firstMaterial?.specular.contents = UIImage(named: "Mars.JPG")
        marSphere.firstMaterial?.emission.contents = UIImage(named: "Mars.JPG")
        
        marNode.position = SCNVector3(0, 0, -1.5)
        
        sceneView.scene.rootNode.addChildNode(marNode)
        
        let action = SCNAction.rotate(by: 360 * CGFloat((M_PI) / 180.0), around: SCNVector3(0, 1, 0), duration: 5)
        let repeatAction = SCNAction.repeatForever(action)
        marNode.runAction(repeatAction)
        
    }
    
    @objc func changeMarsToEarth() {
        player.play()
        marSphere.firstMaterial?.diffuse.contents = UIImage(named: "Earth.JPG")
        marSphere.firstMaterial?.specular.contents = UIImage(named: "EarthNight.JPG")
        marSphere.firstMaterial?.emission.contents = UIImage(named: "EarthClouds.JPG")
    }
    
    func createRing() {
        let ring = SCNTorus(ringRadius: 0.2, pipeRadius: 0.1)
        let ringNode = SCNNode(geometry: ring)
        
        ring.firstMaterial?.diffuse.contents = UIImage(named: "DysonSphere.JPG")
        
        ringNode.position = SCNVector3(0, 0.3, -1.5)
        
        sceneView.scene.rootNode.addChildNode(ringNode)
        
        let action = SCNAction.rotate(by: 360 * CGFloat((M_PI) / 180.0), around: SCNVector3(0, 1, 0), duration: 0.5)
        let moveUpDown = SCNAction.moveBy(x: 0, y: -0.6, z: 0, duration: 10)
        let repeatAction = SCNAction.repeatForever(action)
        ringNode.runAction(moveUpDown)
        ringNode.runAction(repeatAction)
        
    }
    
}


let sceneView = ARSCNView()
let viewController = ViewController(ARsceneView: sceneView)
PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.liveView = viewController.sceneView
PlaygroundPage.current.wantsFullScreenLiveView = true









