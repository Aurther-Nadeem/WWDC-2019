//: # Hope to see you at WWDC. 🏆 
import UIKit
import SceneKit
import PlaygroundSupport


let aboutMeSceneView = SCNView(frame: CGRect(x: 0, y: 0, width: 1200, height: 350))
let aboutMeScene = SCNScene()
aboutMeSceneView.scene = aboutMeScene
aboutMeSceneView.backgroundColor = UIColor(red: 0.088, green: 0.086, blue: 0.214, alpha: 1)

let ourEnvironment = UILabel(frame: CGRect(x: 16, y: 10, width: 200, height: 50))
ourEnvironment.backgroundColor = .clear
ourEnvironment.textColor = UIColor.yellow
ourEnvironment.textAlignment = .center
ourEnvironment.text = "Our Environment: "
ourEnvironment.font = UIFont.boldSystemFont(ofSize: 22)
ourEnvironment.layer.cornerRadius = 10
ourEnvironment.layer.borderColor = UIColor.yellow.cgColor
ourEnvironment.layer.borderWidth = 3
ourEnvironment.layer.shadowColor = ourEnvironment.layer.borderColor
ourEnvironment.layer.shadowRadius = 5
ourEnvironment.layer.shadowOpacity = 0.9
ourEnvironment.layer.shadowOffset = CGSize(width: 0, height: 5)
aboutMeSceneView.addSubview(ourEnvironment)



let theAtmosphere = UILabel(frame: CGRect(x: 230, y: 10, width: 200, height: 50))
theAtmosphere.backgroundColor = .clear
theAtmosphere.textColor = .cyan
theAtmosphere.textAlignment = .center
theAtmosphere.text = "About Me"
theAtmosphere.font = UIFont.boldSystemFont(ofSize: 22)
theAtmosphere.layer.cornerRadius = 10
theAtmosphere.layer.borderColor = UIColor.cyan.cgColor
theAtmosphere.layer.borderWidth = 3
theAtmosphere.layer.shadowColor = theAtmosphere.layer.borderColor
theAtmosphere.layer.shadowRadius = 5
theAtmosphere.layer.shadowOpacity = 0.9
theAtmosphere.layer.shadowOffset = CGSize(width: 0, height: 5)
aboutMeSceneView.addSubview(theAtmosphere)


let AboutMefactOne = UILabel(frame: CGRect(x: 37, y: 75, width: 1050 , height: 570))
AboutMefactOne.textColor = .white
AboutMefactOne.textAlignment = .center
AboutMefactOne.text = "Hey there 👋🏽. My name is Aurther from the UK 🇬🇧. This is my third time applying for WWDC, as I've been rejected twice 😭. Unfortunately, this may be my last chance to get a scholarship for a long time as I am now going to be taking my GCSEs next year and then A-levels for the next two years in the summer 😭. If I get a scholarship this year I will consider it a huge achievement 🏆 and this will be my first WWDC! My first year I applied for a Scholarship (2017) I made a playground which was very basic with just UIImages and UIlabels. Last year (2018) I applied again and used SceneKit which was a jump for me, however I put the complex parts of my Playground at the end 🤦🏽‍♂️ and my Playground was well over the three minutes limit. I believe the two failures have become stepping stones 🧗🏽‍♂️ for me and I have given my all 🏋🏽‍♂️ in the WWDC 2019 Scholarship entry. I have learnt a lot 👨🏽‍🎓 from my failures, like don't put the best things for last if there is a time limit. This year I have implemented ARKit and Core Animation. I'm a huge Apple enthusiast. I have always wanted to go to WWDC as I believe everyone there shares my enthusiasm, pure love for computer science 👨🏾‍💻 and the love for Apple there. Furthermore, I feel like my knowledge will grow at WWDC as I can ask as many questions as I want to all the developers around me. I have created 2 apps which are on the Apple App Store, one called InComp and one called Quickk Maths. My birthday is on the 12th of April, three days before you release the results, it will be an amazing birthday present if I got a Scholarship 🎁. Thanks for your consideration and hopefully I can get a WWDC scholarship this year 🎟."
AboutMefactOne.font = UIFont.boldSystemFont(ofSize: 20)
AboutMefactOne.numberOfLines = 27
AboutMefactOne.translatesAutoresizingMaskIntoConstraints = false
AboutMefactOne.layer.cornerRadius = 10
AboutMefactOne.layer.borderColor = UIColor.white.cgColor
AboutMefactOne.layer.borderWidth = 3
AboutMefactOne.layer.shadowColor = AboutMefactOne.layer.borderColor
AboutMefactOne.layer.shadowRadius = 5
AboutMefactOne.layer.shadowOpacity = 0.9
AboutMefactOne.layer.shadowOffset = CGSize(width: 0, height: 5)
aboutMeSceneView.addSubview(AboutMefactOne)
AboutMefactOne.centerXAnchor.constraint(equalTo: aboutMeSceneView.centerXAnchor).isActive = true
AboutMefactOne.centerYAnchor.constraint(equalTo: aboutMeSceneView.centerYAnchor).isActive = true
AboutMefactOne.heightAnchor.constraint(equalToConstant: 420).isActive = true
AboutMefactOne.widthAnchor.constraint(equalToConstant: 1000).isActive = true

PlaygroundPage.current.liveView = aboutMeSceneView
PlaygroundPage.current.wantsFullScreenLiveView = true


